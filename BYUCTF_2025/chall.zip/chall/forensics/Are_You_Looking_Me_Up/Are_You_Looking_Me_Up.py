#!/usr/bin/env python3
import csv
from collections import Counter

cnt = Counter()
with open('forensics\logs.txt') as f:
    reader = csv.reader(f)
    for row in reader:
        # row[16]=protocol, row[19]=dest IP, row[21]=dest port
        if len(row) > 21 and row[16] == 'udp' and row[21] == '53':
            cnt[row[19]] += 1

# In ra IP nhiều request nhất
ip, num = cnt.most_common(1)[0]
print(f"Top DNS server: {ip} với {num} request")
