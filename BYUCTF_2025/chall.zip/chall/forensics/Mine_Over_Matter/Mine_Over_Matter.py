#!/usr/bin/env python3
import csv
from collections import Counter, defaultdict

# Mở rộng danh sách port khả nghi (Stratum + các port lạ top 10)
mining_ports = {
    '3333','4444','5555','7777',    # stratum mặc định
    '10001','16060','19999','3478','762'
}

conn_count  = Counter()          # số kết nối đến những port mining
byte_count  = defaultdict(int)   # tổng byte từ mỗi src IP

with open(r'forensics/logs.txt', newline='') as f:
    rdr = csv.reader(f)
    for row in rdr:
        if len(row) < 22 or row[16] != 'tcp':
            continue

        src_ip   = row[18]
        dst_port = row[21]
        size     = int(row[12] or 0)

        # đếm kết nối đến port mining
        if dst_port in mining_ports:
            conn_count[src_ip] += 1

        # luôn cộng tổng byte
        byte_count[src_ip] += size

# Top 2 by connection count
top_by_conn = [ip for ip,_ in conn_count.most_common(2)]
# Top 2 by volume
top_by_bytes = sorted(byte_count.items(), key=lambda x: x[1], reverse=True)[:2]
top_by_bytes = [ip for ip,_ in top_by_bytes]

# Gộp 2 kết quả, giữ thứ tự ưu tiên conn_count
suspects = list(dict.fromkeys(top_by_conn + top_by_bytes))[:2]

print("=== Top 2 suspects ===")
for ip in suspects:
    print(ip)
# === Top 2 suspects ===
# 172.16.0.10
# 172.16.16.3

# byuctf{192.168.1.20,172.16.16.3}

#flag đúng
#byuctf{172.16.0.10,172.16.0.5}
