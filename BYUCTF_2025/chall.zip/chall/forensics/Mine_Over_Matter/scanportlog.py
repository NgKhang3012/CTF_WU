#!/usr/bin/env python3
import csv
from collections import Counter

def count_ports(log_path, port_column_index=21):
    """
    Đếm số lần xuất hiện của mỗi port trong log file.
    - log_path: đường dẫn tới file logs.txt
    - port_column_index: chỉ số cột port (0-based). 
         Với destination port là 21, source port là 19.
    """
    counts = Counter()
    with open(log_path, newline='') as f:
        reader = csv.reader(f)
        for row in reader:
            # Skip dòng không đủ cột
            if len(row) <= port_column_index:
                continue
            port = row[port_column_index]
            counts[port] += 1
    return counts

if __name__ == "__main__":
    log_file = "forensics/logs.txt"  # hoặc "logs.txt" tùy vị trí
    dst_counts = count_ports(log_file, port_column_index=21)
    print("=== Top 10 Destination Ports ===")
    for port, cnt in dst_counts.most_common(10):
        print(f"Port {port}: {cnt} hits")

    # Nếu bạn muốn đếm cả source ports, mở thêm:
    src_counts = count_ports(log_file, port_column_index=19)
    print("\n=== Top 10 Source Ports ===")
    for port, cnt in src_counts.most_common(10):
        print(f"Port {port}: {cnt} hits")
