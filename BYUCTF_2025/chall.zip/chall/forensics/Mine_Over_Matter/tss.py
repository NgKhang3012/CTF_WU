import re
from collections import Counter, defaultdict

LOG_PATH = "forensics/logs.txt"  # Đổi lại nếu cần

common_ports = {'80', '443', '53', '123', '1900', '111', '3478'}
ts_re = re.compile(r'^\d{4}-\d{2}-\d{2}T')

port_count = Counter()
port_srcip_count = defaultdict(Counter)
port_srcip_bytes = defaultdict(lambda: defaultdict(int))

with open(LOG_PATH, encoding='latin-1', errors='ignore') as f:
    for raw in f:
        if not ts_re.match(raw): continue
        parts = raw.strip().split(',', 22)
        if len(parts) < 22: continue
        proto    = parts[16]
        src_ip   = parts[18]
        dst_port = parts[21]
        size = 0
        try:
            size = int(parts[12])
        except:
            pass
        port_count[dst_port] += 1
        port_srcip_count[dst_port][src_ip] += 1
        port_srcip_bytes[dst_port][src_ip] += size

# Bắt đầu ghi ra file report
with open("sus_ports_report.txt", "w") as out:
    out.write("=== Top 20 destination ports (all) ===\n")
    for p, c in port_count.most_common(20):
        out.write(f"Port {p}: {c} connections\n")

    out.write("\n=== Suspicious ports (excluding common web/dns/ntp) ===\n")
    sus_ports = [p for p, _ in port_count.most_common(50) if p not in common_ports and p.isdigit()]
    out.write(", ".join(sus_ports) + "\n")

    out.write("\n=== Top 5 src IPs per suspicious port (by connection count) ===\n")
    for p in sus_ports:
        out.write(f"\nPort {p}:\n")
        for ip, cnt in port_srcip_count[p].most_common(5):
            out.write(f"  {ip}: {cnt} connections, {port_srcip_bytes[p][ip]} bytes\n")

print("DONE. Xem file sus_ports_report.txt!")
