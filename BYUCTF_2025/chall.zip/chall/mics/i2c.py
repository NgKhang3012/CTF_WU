# Đọc file Arduino .ino để kiểm tra nội dung và cách xử lý flag
with open('mics\alpha_REDACTED.ino', 'r', encoding='utf-8', errors='ignore') as f:
    code = f.read()

# In ra những dòng đầu tiên để xác định biến flag và mapping segment
print('\n'.join(code.split('\n')[:50]))
