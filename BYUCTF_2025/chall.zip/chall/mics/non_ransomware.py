import requests
import os
import hashlib
import time

# Thư mục lưu mẫu
folder = "bazaar_non_ransomware_exe"
os.makedirs(folder, exist_ok=True)

# Đọc các hash nội dung đã có để tránh trùng
existing_hashes = set()
for fname in os.listdir(folder):
    if fname.endswith(".zip"):
        with open(os.path.join(folder, fname), "rb") as f:
            existing_hashes.add(hashlib.sha256(f.read()).hexdigest())

print(f"[+] Đã có sẵn {len(existing_hashes)} file (theo nội dung)")

# Gọi API get_recent với selector=100 để lấy 100 mẫu mới nhất
print("[+] Đang gọi get_recent (selector=100) từ MalwareBazaar...")
try:
    resp = requests.post("https://mb-api.abuse.ch/api/v1/", data={
        "query": "get_recent",
        "selector": "100"
    })
    resp.raise_for_status()
    data = resp.json().get("data", [])
    if not data:
        print("[!] Không có mẫu trong phản hồi.")
        print(resp.text)
        exit(1)
except Exception as e:
    print("[!] Lỗi khi gọi API hoặc parse JSON:", e)
    exit(1)

# Lọc: bỏ mẫu ransomware, chỉ lấy các file PE32 executable (.exe)
filtered = [
    entry for entry in data
    if "Ransomware" not in entry.get("tags", [])
    and "PE32 executable" in entry.get("file_type", "")
]

print(f"[+] Trong 100 mẫu mới nhất có {len(filtered)} file .exe không phải ransomware")

# Tải về tối đa 100 mẫu đã lọc
count = 0
for entry in filtered:
    sha256 = entry["sha256_hash"]
    out_path = os.path.join(folder, f"{sha256}.zip")

    if os.path.exists(out_path):
        print(f"[SKIP] Đã tồn tại: {sha256}")
        continue

    print(f"[TẢI] {sha256}…")
    try:
        r = requests.post("https://mb-api.abuse.ch/api/v1/", data={
            "query": "get_file",
            "sha256_hash": sha256
        })
        if r.status_code == 200 and r.content.startswith(b"PK"):
            content_hash = hashlib.sha256(r.content).hexdigest()
            if content_hash in existing_hashes:
                print(f"[TRÙNG] Nội dung đã tồn tại: {sha256}")
                continue

            with open(out_path, "wb") as f:
                f.write(r.content)
            existing_hashes.add(content_hash)
            count += 1
            print(f"[✔] Đã lưu: {sha256} ({count}/{len(filtered)})")
        else:
            print(f"[LỖI] Không tải được: {sha256}")
    except Exception as e:
        print(f"[LỖI] Exception khi tải {sha256}: {e}")

    time.sleep(0.3)  # tránh bị rate-limit

print(f"\n[🏁] Hoàn tất. Đã tải {count} file .exe không phải ransomware.")
print(f"[📂] Lưu tại: {os.path.abspath(folder)}")
