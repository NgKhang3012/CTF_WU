target = hash(1337)
i = 2**63           # bắt đầu từ số lớn để CPython vào thuật toán hash khác
while True:
    if hash(i) == target:
        print("Collision found:", i)
        break
    i += 1
# Collision found: 9223372036854777141s